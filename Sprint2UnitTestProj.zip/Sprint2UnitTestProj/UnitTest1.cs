using System.Windows.Forms;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Diagnostics;
using PassGen;

namespace Sprint2UnitTestProj
{
    [TestClass]
    public class UnitTest1
    {
       
        [TestMethod]
        public void TestGeneratePassword()
        {
            // Arrange
            PassGen_Main passGenMain = new PassGen_Main();
            int length = 12;
            bool includeUppercase = true;
            bool includeLowercase = true;
            bool includeNumbers = true;
            bool includeSpecialChars = true;
            bool excludeAmbiguousChars = true;
            bool avoidRepeatingChars = true;

            // Act
            string password = passGenMain.GeneratePassword(length, includeUppercase, includeLowercase, includeNumbers, includeSpecialChars);

            // Assert
            Assert.IsNotNull(password);
            Assert.AreEqual(length, password.Length);

            // Additional assertions for newly added settings
            if (excludeAmbiguousChars)
            {
                Assert.IsFalse(ContainsAtLeastOne(password, "il1Lo0O"), "Generated password contains ambiguous characters");
            }

            if (avoidRepeatingChars)
            {
                Assert.IsTrue(AvoidRepeatingCharacters(password), "Generated password contains repeating characters");
            }
        }

        // Helper method to check for repeating characters
        private bool AvoidRepeatingCharacters(string password)
        {
            for (int i = 0; i < password.Length - 1; i++)
            {
                if (password[i] == password[i + 1])
                {
                    return false;
                }
            }
            return true;
        }

        [TestMethod]
            public void TestUppercaseAndLowercaseCharacters()
            {
                // Arrange
                int expectedLength = 10;
                bool includeUppercase = true;
                bool includeLowercase = true;
                bool includeNumbers = false;
                bool includeSpecialChars = false;

                // Act
                PassGen_Main passGenMain = new PassGen_Main();
                string generatedPassword = passGenMain.GeneratePassword(expectedLength, includeUppercase, includeLowercase, includeNumbers, includeSpecialChars);

                // Assert
                Assert.AreEqual(expectedLength, generatedPassword.Length, "Generated password length does not match expected length");
                Assert.IsTrue(ContainsAtLeastOne(generatedPassword, "ABCDEFGHIJKLMNOPQRSTUVWXYZ"), "Generated password does not contain at least one uppercase character");
                Assert.IsTrue(ContainsAtLeastOne(generatedPassword, "abcdefghijklmnopqrstuvwxyz"), "Generated password does not contain at least one lowercase character");
            }

         [TestMethod]
            public void TestNumericCharacters()
            {
                // Arrange
                int expectedLength = 10;
                bool includeUppercase = false;
                bool includeLowercase = false;
                bool includeNumbers = true;
                bool includeSpecialChars = false;

                // Act
                PassGen_Main passGenMain = new PassGen_Main();
                string generatedPassword = passGenMain.GeneratePassword(expectedLength, includeUppercase, includeLowercase, includeNumbers, includeSpecialChars);

                // Assert
                Assert.AreEqual(expectedLength, generatedPassword.Length, "Generated password length does not match expected length");
                Assert.IsTrue(ContainsAtLeastOne(generatedPassword, "1234567890"), "Generated password does not contain at least one numeric character");
            }

         [TestMethod]
            public void TestSpecialCharacters()
            {
                // Arrange
                int expectedLength = 10;
                bool includeUppercase = false;
                bool includeLowercase = false;
                bool includeNumbers = false;
                bool includeSpecialChars = true;

                // Act
                PassGen_Main passGenMain = new PassGen_Main();
                string generatedPassword = passGenMain.GeneratePassword(expectedLength, includeUppercase, includeLowercase, includeNumbers, includeSpecialChars);

                // Assert
                Assert.AreEqual(expectedLength, generatedPassword.Length, "Generated password length does not match expected length");
                Assert.IsTrue(ContainsAtLeastOne(generatedPassword, "!@#$%^&*()_+-=[]{}|;:,.<>?"), "Generated password does not contain at least one special character");
            }

            // Helper method to check for specific characters
            private bool ContainsAtLeastOne(string text, string characters)
            {
                foreach (char c in characters)
                {
                    if (text.Contains(c))
                    {
                        return true;
                    }
                }
                return false;
            }

        [TestMethod]
            public void TestPasswordGenerationTime()
            {
                // Define the parameters for testing
                int[] lengths = { 8, 12, 20 }; // Varying lengths of passwords to test
                bool includeLowercase = true;
                bool includeUppercase = true;
                bool includeNumbers = true;
                bool includeSpecialChars = true;

                // Test password generation time for each length
                foreach (int length in lengths)
                {
                    // Start the stopwatch to measure time
                    Stopwatch stopwatch = Stopwatch.StartNew();

                    // Generate the password
                    PassGen_Main passGenMain = new PassGen_Main();
                    string password = passGenMain.GeneratePassword(length, includeLowercase, includeUppercase, includeNumbers, includeSpecialChars);

                    // Stop the stopwatch
                    stopwatch.Stop();

                    // Calculate and output the elapsed time
                    Console.WriteLine($"Password length: {length}, Time taken: {stopwatch.ElapsedMilliseconds} milliseconds");
                }
            }

        [TestMethod]
            public void TestExcludeAmbiguousCharacters()
            {
                // Arrange
                PassGen_Main passGen = new PassGen_Main();

                // Act
                string password = passGen.GeneratePassword(12, true, true, true, true);

                // Assert
                Assert.IsFalse(ContainsAtLeastOne(password, "il1Lo0O"));
            }

        [TestMethod]
            public void TestAvoidRepeatingCharacters()
            {
                // Arrange
                PassGen_Main passGen = new PassGen_Main();

                // Act
                string password1 = passGen.GeneratePassword(12, true, true, true, true);
                string password2 = passGen.GeneratePassword(12, true, true, true, true);

                // Assert
                Assert.AreNotEqual(password1, password2);
            }
    }
}